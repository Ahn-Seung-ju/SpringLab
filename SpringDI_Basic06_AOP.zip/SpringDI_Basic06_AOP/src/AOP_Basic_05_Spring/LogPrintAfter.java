package AOP_Basic_05_Spring;

public class LogPrintAfter {

}
