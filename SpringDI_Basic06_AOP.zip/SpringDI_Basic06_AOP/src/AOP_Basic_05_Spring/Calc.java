package AOP_Basic_05_Spring;

public interface Calc {
	int ADD(int x, int y);
	int MUL(int x, int y);
	int SUB(int x, int y);
	
}
