package AOP_Basic_01;

public class Program {

	public static void main(String[] args) {

		Calc calc = new Calc();
		
		calc.Add(1000, 1000);
		
		calc.Mul(23, 19);
	}

}
